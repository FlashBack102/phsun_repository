package com.example.start.admin.persistence;

public interface AdminDAO {

	public int boardDelete(int boardNum);
}
